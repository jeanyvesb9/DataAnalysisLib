# DataAnalysisLib
Open Source library developed for in-lab easy data analysis and processing. Intended for student use in experimental Physics labs. Developed by @jeanyvesb9 and @aguscaputobugallo